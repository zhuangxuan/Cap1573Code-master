## Info

This folder examines the {{render "dir/templatefilename"}} functionality to manually render any template inside any template
