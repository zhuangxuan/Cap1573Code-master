# Repositories

The package which has direct access to the "datasource" and can manipulate data directly.